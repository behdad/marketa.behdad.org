import * as fs from "fs";

import { src, dest, series, parallel } from "gulp";
import del from "del";

import sourcemaps from "gulp-sourcemaps";
import terser from "gulp-terser";
import size from "gulp-size";
import browserify from "browserify";
import buffer from "vinyl-buffer";
import source from "vinyl-source-stream";
import replace from "gulp-replace";

// eslint-disable-next-line
const tsify = require("tsify");
// eslint-disable-next-line
const footer = require("gulp-footer");

function clean() {
    return del(["dist/emulators*",
        "build/wworker-footer*"], { force: true });
}

function browserifyTs(src: string, dst: string) {
    return browserify({
        debug: true,
        entries: [src],
        cache: {},
        packageCache: {},
    })
        .plugin(tsify, {
            "target": "esnext",
        })
        .transform("babelify", {
            presets: [["@babel/preset-env", {
                "useBuiltIns": "usage",
                "corejs": 3,
            }]],
            extensions: [".ts"],
        })
        .bundle()
        .pipe(source(dst))
        .pipe(buffer())
        .pipe(sourcemaps.init({ loadMaps: true }))
        .pipe(terser())
        .pipe(sourcemaps.write("./"))
        .pipe(size({ showFiles: true, showTotal: false }))
        .pipe(dest("dist"));
}

function emulatorsJs() {
    return browserifyTs("src/emulators.ts", "emulators.js");
}

function sockdriveJs() {
    return browserifyTs("src/sockdrive/sockdrive.ts", "sockdrive.js");
}

function dosboxJs() {
    return src("dist/wdosbox.js")
        .pipe(footer(fs.readFileSync("src/dos/dosbox/ts/worker-server.js")))
        .pipe(replace("@MODULE_NAME@", "WDOSBOX"))
        .pipe(replace("@SOCKDRIVE@", ""))
        .pipe(dest("dist"));
}

function dosboxxJs() {
    return src("dist/wdosbox-x.js")
        .pipe(footer(fs.readFileSync("src/dos/dosbox/ts/worker-server.js")))
        .pipe(replace("@MODULE_NAME@", "WDOSBOXX"))
        .pipe(replace("@SOCKDRIVE@", fs.readFileSync("dist/sockdrive.js", "utf8")))
        .pipe(dest("dist"));
}

function dosboxxJsJspi() {
    return src("dist/wdosbox-x-jspi.js")
        .pipe(footer(fs.readFileSync("src/dos/dosbox/ts/worker-server.js")))
        .pipe(replace("@MODULE_NAME@", "WDOSBOXXJSPI"))
        .pipe(replace("@SOCKDRIVE@", fs.readFileSync("dist/sockdrive.js", "utf8")))
        .pipe(dest("dist"));
}

function cleanupJs() {
    return del("dist/sockdrive.js");
}

export const compileJs = series(clean, parallel(emulatorsJs, sockdriveJs));
export const emulators = series(parallel(dosboxJs, dosboxxJs, dosboxxJsJspi), cleanupJs);
