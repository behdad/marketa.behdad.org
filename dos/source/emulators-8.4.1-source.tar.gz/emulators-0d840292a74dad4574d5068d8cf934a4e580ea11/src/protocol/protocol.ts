import {
    CommandInterface, NetworkType, BackendOptions, DosConfig,
    InitFsEntry, InitFileEntry,
} from "../emulators";
import { CommandInterfaceEventsImpl } from "../impl/ci-impl";

const maxDataChunkSize = 4 * 1024 * 1024;

type Peer = {
    peerId: number;
}

export type Net = {
    peerId: number;
    connected: Set<number>;
    wait: (ms: number) => void;
    registerAlias: (alias: string) => Promise<void>;
    unregisterAlias: (alias: string) => void;
    queryAliases: (query: string) => Promise<Peer[]>;
    sendBinary: (data: Uint8Array, peerId: number) => number;
    recvBinary: () => { data: Uint8Array, peerId: number } | null;
    disconnect: (peerId: number) => void;
}

export type ClientMessage =
    "wc-install" |
    "wc-run" |
    "wc-pack-fs-to-bundle" |
    "wc-add-key" |
    "wc-mouse-move" |
    "wc-mouse-button" |
    "wc-mouse-sync" |
    "wc-exit" |
    "wc-sync-sleep" |
    "wc-pause" |
    "wc-resume" |
    "wc-mute" |
    "wc-unmute" |
    "wc-connect" |
    "wc-disconnect" |
    "wc-backend-event" |
    "wc-asyncify-stats" |
    "wc-fs-tree" |
    "wc-fs-get-file" |
    "wc-send-data-chunk" |
    "wc-net-connected" |
    "wc-net-received" |
    "wc-unload" |
    "wc-fs-delete-file" |
    "wc-persist-sockdrives" |
    "wc-get-running-program";

export type ServerMessage =
    "ws-extract-progress" |
    "ws-ready" |
    "ws-server-ready" |
    "ws-frame-set-size" |
    "ws-update-lines" |
    "ws-log" |
    "ws-warn" |
    "ws-err" |
    "ws-stdout" |
    "ws-exit" |
    "ws-persist" |
    "ws-sound-init" |
    "ws-sound-push" |
    "ws-config" |
    "ws-sync-sleep" |
    "ws-connected" |
    "ws-disconnected" |
    "ws-asyncify-stats" |
    "ws-fs-tree" |
    "ws-send-data-chunk" |
    "ws-net-disconnect" |
    "ws-net-send" |
    "ws-unload" |
    "ws-fs-delete-file" |
    "ws-persist-sockdrives" |
    "ws-get-running-program";

export type MessageHandler = (name: ServerMessage, props: { [key: string]: any }) => void;

export interface TransportLayer {
    sessionId: string;
    sendMessageToServer(name: ClientMessage,
        props: { [key: string]: any },
        transfer?: Transferable[]): void;
    initMessageHandler(handler: MessageHandler): void;
    exit?: () => void;
    net: Net | null;
}

export interface FrameLine {
    start: number;
    heapu8: Uint8Array;
}

export interface DataChunk {
    type: "ok" | "file" | "bundle";
    name: string;
    data: ArrayBuffer | null;
}

export interface CPUMetrics {
    cpuMax: number;
    emulatorSpeed: number;
    cpuUsed: number;
    frameSkip: number;
    fastForward: boolean;
    cpuSockdrive: boolean;
    cpuAuto: boolean;
    cpuSkip: boolean;
    sleepPattern: string;
    ratio: number[];
    newCmax: number[];
    ticksDone: number[];
    ticksScheduled: number[];
}

export interface AsyncifyStats {
    glfx?: boolean,
    offscreenCanvas?: boolean,
    messageSent: number,
    messageReceived: number,
    messageFrame: number,
    messageSound: number,
    nonSkippableSleepCount: number,
    sleepCount: number,
    sleepTime: number,
    cpuMetrics: CPUMetrics | null,
    netSent: number,
    netRecv: number,
    driveIo: {
        url: string,
        preload: number,
        total: number,
        read: number,
        write: number,
    }[];
}

export interface FsNode {
    name: string,
    size: number | null,
    nodes: FsNode[] | null,
}

export class CommandInterfaceOverTransportLayer implements CommandInterface {
    private startedAt = Date.now();
    private exited = false;
    private frameWidth = 0;
    private frameHeight = 0;
    private rgb: Uint8Array | null = null;
    private rgba: Uint8Array | null = null;
    private freq = 0;
    private utf8Decoder = new TextDecoder();

    private init?: InitFsEntry[];
    private transport: TransportLayer;
    private ready: (err: Error | null) => void;

    private persistPromise?: Promise<Uint8Array | null>;
    private persistResolve?: (bundle: Uint8Array | null) => void;

    private exitPromise?: Promise<void>;
    private exitResolve?: () => void;

    private eventsImpl = new CommandInterfaceEventsImpl();

    private keyMatrix: { [keyCode: number]: boolean } = {};

    private configPromise: Promise<DosConfig>;
    private configResolve: (config: DosConfig) => void = () => {/**/};
    private panicMessages: string[] = [];

    private connectPromise: Promise<void> | null = null;
    private connectResolve: () => void = () => {/**/};
    private connectReject: () => void = () => {/**/};

    private disconnectPromise: Promise<void> | null = null;
    private disconnectResolve: () => void = () => {/**/};

    private asyncifyStatsPromise: Promise<AsyncifyStats> | null = null;
    private asyncifyStatsResolve: (stats: AsyncifyStats) => void = () => {/**/};

    private fsTreePromise: Promise<FsNode> | null = null;
    private fsTreeResolve: (fsRoot: FsNode) => void = () => {/**/};

    private fsGetFilePromise: { [name: string]: Promise<Uint8Array> } = {};
    private fsGetFileResolve: { [name: string]: (file: Uint8Array) => void } = {};
    private fsGetFileParts: { [name: string]: Uint8Array[] } = {};

    private fsDeleteFilePromise: Promise<boolean> | null = null;
    private fsDeleteFileResolve: (deleted: boolean) => void = () => {/**/};

    private getRunningProgramPromise: Promise<string> | null = null;
    private getRunningProgramResolve: (program: string) => void = () => {/**/};

    private dataChunkPromise: { [name: string]: Promise<void> } = {};
    private dataChunkResolve: { [name: string]: () => void } = {};

    private persistSockdrivesPromise: Promise<Uint8Array | null> | null = null;
    private persistSockdrivesResolve: (changes: Uint8Array | null) => void = () => {/**/};

    private myPeerId: number = 0;
    private netSent = 0;
    private netRecv = 0;
    private netPollInterval: ReturnType<typeof setInterval> | null = null;

    public options: BackendOptions;

    constructor(init: InitFsEntry[],
        transport: TransportLayer,
        ready: (err: Error | null) => void,
        options: BackendOptions) {
        this.options = options;
        this.init = init;
        this.transport = transport;
        this.ready = ready;
        this.configPromise = new Promise<DosConfig>((resolve) => this.configResolve = resolve);
        this.transport.initMessageHandler(this.onServerMessage.bind(this));
        this.transport.net = this.transport.net ?? null;
        if (this.transport.net) {
            this.myPeerId = this.transport.net.peerId;
            this.netPollInterval = setInterval(() => {
                this.transport.net!.wait(0);

                let data = this.transport.net!.recvBinary();
                while (data != null) {
                    this.netRecv += data.data.length;
                    this.sendClientMessage("wc-net-received", {
                        peerId: data.peerId,
                        data: data.data.buffer,
                    }, [data.data.buffer]);
                    data = this.transport.net!.recvBinary();
                }
            }, 16);
        }
    }

    private sendClientMessage(name: ClientMessage, props?: { [key: string]: any }, transfer?: [ArrayBuffer]) {
        props = props || {};
        props.sessionId = props.sessionId || this.transport.sessionId;
        this.transport.sendMessageToServer(name, props, transfer);
    }


    private onServerMessage(name: ServerMessage, props: { [key: string]: any }) {
        if (name === undefined || name.length < 3 ||
            name[0] !== "w" || name[1] !== "s" || name[2] !== "-") {
            return;
        }

        if (props === undefined || props.sessionId !== this.transport.sessionId) {
            return;
        }

        switch (name) {
            case "ws-ready": {
                const sendBundles = async () => {
                    if (!this.init || this.init.length === 0) {
                        return;
                    }

                    const encoder = new TextEncoder();
                    const sendData = async (type: "file" | "bundle", name: string, contents: Uint8Array) => {
                        await this.sendDataChunk({
                            type,
                            name,
                            data: contents.buffer,
                        });

                        await this.sendDataChunk({
                            type,
                            name,
                            data: null,
                        });
                    };

                    let bundleIndex = 0;
                    for (const next of this.init) {
                        if (ArrayBuffer.isView(next)) {
                            await sendData("bundle", bundleIndex + "", next);
                            bundleIndex++;
                        } else if (typeof next === "string") {
                            await sendData("file", ".jsdos/dosbox.conf", encoder.encode(next));
                        } else {
                            const fileEntry = next as InitFileEntry;
                            const dosConfig = next as DosConfig;

                            if (dosConfig.jsdosConf?.version !== undefined) {
                                await sendData("file", ".jsdos/dosbox.conf",
                                    encoder.encode(dosConfig.dosboxConf));
                                await sendData("file", ".jsdos/jsdos.json",
                                    encoder.encode(JSON.stringify(dosConfig.jsdosConf, null, 2)));
                            } else if (fileEntry.path !== undefined) {
                                await sendData("file", fileEntry.path, fileEntry.contents);
                            } else {
                                console.error("Unknown init part", next);
                            }
                        }
                    }
                };

                sendBundles()
                    .then(() => {
                        this.sendClientMessage("wc-run", {
                            token: this.options.token,
                            myPeerId: this.myPeerId,
                            sockdrivePreload: this.options.sockdrivePreload,
                        });
                    })
                    .catch((e) => {
                        this.onErr("panic", "Can't send bundles to backend: " + e.message);
                        console.error(e);
                    })
                    .finally(() => {
                        delete this.init;
                    });
            } break;
            case "ws-server-ready": {
                if (this.panicMessages.length > 0) {
                    if (this.transport.exit !== undefined) {
                        this.transport.exit();
                    }
                    this.ready(new Error(JSON.stringify(this.panicMessages)));
                } else {
                    this.ready(null);
                }
                delete (this as any).ready;
            } break;
            case "ws-frame-set-size": {
                this.onFrameSize(props.width, props.height);
            } break;
            case "ws-update-lines": {
                this.onFrameLines(props.lines, props.rgba);
            } break;
            case "ws-exit": {
                this.onExit();
            } break;
            case "ws-log": {
                // eslint-disable-next-line
                this.onLog(props.tag, props.message);
            } break;
            case "ws-warn": {
                // eslint-disable-next-line
                this.onWarn(props.tag, props.message);
            } break;
            case "ws-err": {
                // eslint-disable-next-line
                this.onErr(props.tag, props.message);
            } break;
            case "ws-stdout": {
                this.onStdout(props.message);
            } break;
            case "ws-persist": {
                this.onPersist(props.bundle ?? props.sockdrives ?? null);
            } break;
            case "ws-sound-init": {
                this.onSoundInit(props.freq);
            } break;
            case "ws-sound-push": {
                this.onSoundPush(props.samples);
            } break;
            case "ws-config": {
                this.onConfig({
                    dosboxConf: this.utf8Decoder.decode(props.dosboxConf),
                    jsdosConf: JSON.parse(props.jsdosConf),
                });
            } break;
            case "ws-sync-sleep": {
                this.sendClientMessage("wc-sync-sleep", props);
            } break;
            case "ws-connected": {
                this.connectResolve();
                this.connectPromise = null;
                this.connectResolve = () => {/**/};
                this.connectReject = () => {/**/};
                this.eventsImpl.fireNetworkConnected(props.networkType, props.address);
            } break;
            case "ws-disconnected": {
                if (this.connectPromise !== null) {
                    this.connectReject();
                    this.connectPromise = null;
                    this.connectResolve = () => {/**/};
                    this.connectReject = () => {/**/};
                } else {
                    this.disconnectResolve();
                    this.disconnectPromise = null;
                    this.disconnectResolve = () => {/**/};
                }
                this.eventsImpl.fireNetworkDisconnected(props.networkType);
            } break;
            case "ws-extract-progress": {
                if (this.options.onExtractProgress) {
                    this.options.onExtractProgress(props.index, props.file, props.extracted, props.count);
                }
            } break;
            case "ws-asyncify-stats": {
                props.netSent = this.netSent;
                props.netRecv = this.netRecv;
                if (props.cpuMetrics && props.cpuMetrics.length > 0) {
                    const partial = props.cpuMetrics.split(" ");
                    const cpu = partial[0].split("|");
                    const metrics: CPUMetrics = {
                        cpuMax: parseInt(cpu[0]),
                        emulatorSpeed: parseInt(cpu[1]) / 100,
                        cpuUsed: parseInt(cpu[2]) / 100,
                        frameSkip: parseInt(cpu[3]),
                        fastForward: cpu[4][0] === "1",
                        cpuSockdrive: cpu[4][1] === "1",
                        cpuAuto: cpu[4][2] === "1",
                        cpuSkip: cpu[4][3] === "1",
                        sleepPattern: "",
                        ratio: [],
                        newCmax: [],
                        ticksDone: [],
                        ticksScheduled: [],
                    };

                    for (let i = 1; i < partial.length; i++) {
                        if (partial[i][0] === "r") {
                            const parts = partial[i].split("|");
                            metrics.ratio.push(parseInt(parts[0].substring(1)) / 1024);
                            metrics.newCmax.push(parseInt(parts[1]));
                            metrics.ticksDone.push(parseInt(parts[2]));
                            metrics.ticksScheduled.push(parseInt(parts[3]));
                        } else {
                            metrics.sleepPattern += partial[i] + " ";
                        }
                    }
                    props.cpuMetrics = metrics;
                } else {
                    props.cpuMetrics = null;
                }
                this.asyncifyStatsResolve(props as AsyncifyStats);
                this.asyncifyStatsResolve = () => {/**/};
                this.asyncifyStatsPromise = null;
            } break;
            case "ws-fs-tree": {
                this.fsTreeResolve(props.fsTree as FsNode);
                this.fsTreeResolve = () => {/**/};
                this.fsTreePromise = null;
            } break;
            case "ws-fs-delete-file": {
                this.fsDeleteFileResolve(props.deleted);
                this.fsDeleteFileResolve = () => {/**/};
                this.fsDeleteFilePromise = null;
            } break;
            case "ws-send-data-chunk": {
                const chunk: DataChunk = props.chunk;
                const key = this.dataChunkKey(chunk);
                if (chunk.type === "ok") {
                    if (this.dataChunkPromise[key] !== undefined) {
                        this.dataChunkResolve[key]();
                        delete this.dataChunkPromise[key];
                        delete this.dataChunkResolve[key];
                    }
                } else if (chunk.type === "file") {
                    if (chunk.data === null) {
                        const file = this.mergeChunks(this.fsGetFileParts[chunk.name]);
                        this.fsGetFileResolve[chunk.name](file);
                        delete this.fsGetFilePromise[chunk.name];
                        delete this.fsGetFileResolve[chunk.name];
                    } else {
                        this.fsGetFileParts[chunk.name].push(new Uint8Array(chunk.data));
                    }
                } else {
                    console.log("Unknown chunk type:", chunk.type);
                }
            } break;
            case "ws-net-send": {
                this.netSent += props.data.length;
                const response = this.transport.net?.sendBinary(new Uint8Array(props.data), props.peerId);
                if (response === 0) {
                    const retryFn = () => {
                        if (this.transport.net?.sendBinary(new Uint8Array(props.data), props.peerId) === 0) {
                            setTimeout(retryFn, 100);
                        }
                    };
                    setTimeout(retryFn, 100);
                }
            } break;
            case "ws-net-disconnect": {
                this.transport.net?.disconnect(props.peerId);
            } break;
            case "ws-unload": {
                this.eventsImpl.fireUnload().finally(() => {
                    this.sendClientMessage("wc-unload");
                });
            } break;
            case "ws-persist-sockdrives": {
                if (props.drives === null) {
                    this.persistSockdrivesResolve(null);
                } else {
                    this.persistSockdrivesResolve(encodeSockdriveChanges(props.drives));
                }
                this.persistSockdrivesResolve = () => {/**/};
                this.persistSockdrivesPromise = null;
            } break;
            case "ws-get-running-program": {
                if (this.getRunningProgramPromise !== null) {
                    this.getRunningProgramResolve(props.program);
                    this.getRunningProgramResolve = () => {/**/};
                    this.getRunningProgramPromise = null;
                }
            } break;
            default: {
                // eslint-disable-next-line
                console.log("Unknown server message (ws):", name);
            } break;
        }
    }

    private onConfig(config: DosConfig) {
        this.configResolve(config);
    }

    private onFrameSize(width: number, height: number) {
        if (this.frameWidth === width && this.frameHeight === height) {
            return;
        }

        this.frameWidth = width;
        this.frameHeight = height;
        this.rgb = new Uint8Array(width * height * 3);
        this.eventsImpl.fireFrameSize(width, height);
    }

    private onFrameLines(lines: FrameLine[], rgbaPtr: number) {
        for (const line of (lines as FrameLine[])) {
            this.rgb!.set(line.heapu8, line.start * this.frameWidth * 3);
        }

        this.eventsImpl.fireFrame(this.rgb, this.rgba);
    }

    private onSoundInit(freq: number) {
        this.freq = freq;
    }

    private onSoundPush(samples: Float32Array) {
        this.eventsImpl.fireSoundPush(samples);
    }

    private onLog(tag: string, message: string) {
        this.eventsImpl.fireMessage("log", "[" + tag + "]" + message);
    }

    private onWarn(tag: string, message: string) {
        this.eventsImpl.fireMessage("warn", "[" + tag + "]" + message);
    }

    private onErr(tag: string, message: string) {
        if (tag === "panic") {
            this.panicMessages.push(message);
            console.error("[" + tag + "]" + message);
        }
        this.eventsImpl.fireMessage("error", "[" + tag + "]" + message);
    }

    private onStdout(message: string) {
        this.eventsImpl.fireStdout(message);
    }

    public config() {
        return this.configPromise;
    }

    public width() {
        return this.frameWidth;
    }

    public height() {
        return this.frameHeight;
    }

    public soundFrequency() {
        return this.freq;
    }

    public screenshot(): Promise<ImageData> {
        if (this.rgb !== null || this.rgba !== null) {
            const rgba = new Uint8ClampedArray(this.frameWidth * this.frameHeight * 4);
            const frame = (this.rgb !== null ? this.rgb : this.rgba) as Uint8Array;

            let frameOffset = 0;
            let rgbaOffset = 0;

            while (rgbaOffset < rgba.length) {
                rgba[rgbaOffset++] = frame[frameOffset++];
                rgba[rgbaOffset++] = frame[frameOffset++];
                rgba[rgbaOffset++] = frame[frameOffset++];
                rgba[rgbaOffset++] = 255;

                if (frame.length === rgba.length) {
                    frameOffset++;
                }
            }

            return Promise.resolve(new ImageData(rgba, this.frameWidth, this.frameHeight));
        } else {
            return Promise.reject(new Error("No frame received"));
        }
    }

    public simulateKeyPress(...keyCodes: number[]) {
        const timeMs = Date.now() - this.startedAt;
        keyCodes.forEach((keyCode) => this.addKey(keyCode, true, timeMs));
        keyCodes.forEach((keyCode) => this.addKey(keyCode, false, timeMs + 16));
    }

    public sendKeyEvent(keyCode: number, pressed: boolean) {
        this.addKey(keyCode, pressed, Date.now() - this.startedAt);
    }

    // public for test
    public addKey(keyCode: number, pressed: boolean, timeMs: number) {
        const keyPressed = this.keyMatrix[keyCode] === true;
        if (keyPressed === pressed) {
            return;
        }
        this.keyMatrix[keyCode] = pressed;
        this.sendClientMessage("wc-add-key", { key: keyCode, pressed, timeMs });
    }

    public sendMouseMotion(x: number, y: number) {
        this.sendClientMessage("wc-mouse-move", { x, y, relative: false, timeMs: Date.now() - this.startedAt });
    }

    public sendMouseRelativeMotion(x: number, y: number) {
        this.sendClientMessage("wc-mouse-move", { x, y, relative: true, timeMs: Date.now() - this.startedAt });
    }

    public sendMouseButton(button: number, pressed: boolean) {
        this.sendClientMessage("wc-mouse-button", { button, pressed, timeMs: Date.now() - this.startedAt });
    }

    public sendMouseSync() {
        this.sendClientMessage("wc-mouse-sync", { timeMs: Date.now() - this.startedAt });
    }

    public sendBackendEvent(payload: any) {
        this.sendClientMessage("wc-backend-event", { json: JSON.stringify(payload) });
    }


    public async persist(optOnlyChanges?: boolean): Promise<Uint8Array | null> {
        const onlyChanges = optOnlyChanges ?? true;
        if (this.persistPromise !== undefined) {
            return this.persistPromise;
        }

        const sockdrives = await this.persistSockdrives();
        if (sockdrives !== null && onlyChanges) {
            return Promise.resolve(sockdrives);
        }

        const persistPromise = new Promise<Uint8Array | null>((resolve) => {
            this.persistResolve = resolve;
        });
        this.persistPromise = persistPromise;
        this.sendClientMessage("wc-pack-fs-to-bundle", {
            onlyChanges,
        });

        return persistPromise;
    }

    private onPersist(bundle: Uint8Array | null) {
        if (this.persistResolve) {
            this.persistResolve(bundle);
            delete this.persistPromise;
            delete this.persistResolve;
        }
    }

    public pause() {
        this.sendClientMessage("wc-pause");
    }

    public resume() {
        this.sendClientMessage("wc-resume");
    }

    public mute() {
        this.sendClientMessage("wc-mute");
    }

    public unmute() {
        this.sendClientMessage("wc-unmute");
    }

    public exit(): Promise<void> {
        if (this.exited) {
            return Promise.resolve();
        }
        if (this.exitPromise !== undefined) {
            return this.exitPromise;
        }
        this.exitPromise = new Promise<void>((resolve) => this.exitResolve = resolve);
        this.exitPromise.then(() => {
            this.events().fireExit();
        });

        this.resume();
        for (const next of this.transport.net?.connected ?? []) {
            this.transport.net?.disconnect(next);
        }
        this.sendClientMessage("wc-exit");

        return this.exitPromise;
    }

    private onExit() {
        if (!this.exited) {
            this.exited = true;
            if (this.netPollInterval !== null) {
                clearInterval(this.netPollInterval);
                this.netPollInterval = null;
            }
            if (this.transport.exit !== undefined) {
                this.transport.exit();
            }
            if (this.exitResolve) {
                this.exitResolve();
                delete this.exitPromise;
                delete this.exitResolve;
            }
        }
    }

    public events() {
        return this.eventsImpl;
    }

    public networkConnect(networkType: NetworkType, address: string): Promise<void> {
        if (this.connectPromise !== null || this.disconnectPromise !== null) {
            return Promise.reject(new Error("Already prefoming connection or disconnection..."));
        }

        this.connectPromise = new Promise<void>((resolve, reject) => {
            this.connectResolve = resolve;
            this.connectReject = reject;
            this.sendClientMessage("wc-connect", {
                networkType,
                address,
            });
        });
        return this.connectPromise;
    }

    public networkDisconnect(networkType: NetworkType): Promise<void> {
        if (this.connectPromise !== null || this.disconnectPromise !== null) {
            return Promise.reject(new Error("Already prefoming connection or disconnection..."));
        }

        this.disconnectPromise = new Promise<void>((resolve) => {
            this.disconnectResolve = resolve;

            this.sendClientMessage("wc-disconnect", {
                networkType,
            });
        });
        return this.disconnectPromise;
    }

    public asyncifyStats(): Promise<AsyncifyStats> {
        if (this.asyncifyStatsPromise !== null) {
            return this.asyncifyStatsPromise;
        }

        const promise = new Promise<AsyncifyStats>((resolve) => {
            this.asyncifyStatsResolve = resolve;
        });

        this.asyncifyStatsPromise = promise;
        this.sendClientMessage("wc-asyncify-stats", {});

        return promise;
    }

    public fsTree(): Promise<FsNode> {
        if (this.fsTreePromise !== null) {
            return this.fsTreePromise;
        }

        const promise = new Promise<FsNode>((resolve) => {
            this.fsTreeResolve = resolve;
        });
        this.fsTreePromise = promise;
        this.sendClientMessage("wc-fs-tree");

        return promise;
    }

    async fsReadFile(file: string): Promise<Uint8Array> {
        if (this.fsGetFilePromise[file] !== undefined) {
            throw new Error("fsGetFile should not be called twice for same file");
        }

        const promise = new Promise<Uint8Array>((resolve) => {
            this.fsGetFileResolve[file] = resolve;
        });
        this.fsGetFilePromise[file] = promise;
        this.fsGetFileParts[file] = [];
        this.sendClientMessage("wc-fs-get-file", {
            file,
        });

        return promise;
    }

    async fsWriteFile(file: string, contents: ReadableStream<Uint8Array> | Uint8Array): Promise<void> {
        if (ArrayBuffer.isView(contents)) {
            await this.sendDataChunk({
                type: "file",
                name: file,
                data: contents.buffer,
            });
        } else {
            const reader = contents.getReader();
            while (true) {
                const result = await reader.read();
                if (result.value !== undefined) {
                    await this.sendDataChunk({
                        type: "file",
                        name: file,
                        data: result.value.buffer,
                    });
                }
                if (result.done) {
                    break;
                }
            }
        }

        await this.sendDataChunk({
            type: "file",
            name: file,
            data: null,
        });
    }

    async fsDeleteFile(file: string): Promise<boolean> {
        if (this.fsDeleteFilePromise !== null) {
            throw new Error("fsDeleteFile should not be called while previous one is not resolved");
        }

        const promise = new Promise<boolean>((resolve) => {
            this.fsDeleteFileResolve = resolve;
        });
        this.fsDeleteFilePromise = promise;
        this.sendClientMessage("wc-fs-delete-file", { file });
        return promise;
    }

    async persistSockdrives(): Promise<Uint8Array | null> {
        if (this.persistSockdrivesPromise === null) {
            this.persistSockdrivesPromise = new Promise<Uint8Array | null>((resolve) => {
                this.persistSockdrivesResolve = resolve;
            });
            this.sendClientMessage("wc-persist-sockdrives");
        }
        return this.persistSockdrivesPromise;
    }

    private async sendDataChunk(chunk: DataChunk): Promise<void> {
        if (chunk.data === null || chunk.data.byteLength <= maxDataChunkSize) {
            return this.sendFullDataChunk(chunk);
        } else {
            let pos = 0;
            while (pos < chunk.data.byteLength) {
                await this.sendFullDataChunk({
                    type: chunk.type,
                    name: chunk.name,
                    data: chunk.data.slice(pos, Math.min(chunk.data.byteLength, pos + maxDataChunkSize)),
                });
                pos += maxDataChunkSize;
            }
        }
    }

    private async sendFullDataChunk(chunk: DataChunk): Promise<void> {
        const key = this.dataChunkKey(chunk);
        if (this.dataChunkPromise[key] !== undefined) {
            throw new Error("sendDataChunk should be accepted before sending new one");
        }
        const promise = new Promise<void>((resolve) => {
            this.dataChunkResolve[key] = resolve;
        });
        this.dataChunkPromise[key] = promise;
        this.sendClientMessage("wc-send-data-chunk", {
            chunk,
        }, chunk.data === null ? undefined : [chunk.data]);
        return promise;
    }

    private dataChunkKey(chunk: DataChunk) {
        return chunk.name;
    }

    private mergeChunks(parts: Uint8Array[]): Uint8Array {
        if (parts.length === 1) {
            return parts[0];
        }

        let length = 0;
        for (const next of parts) {
            length += next.byteLength;
        }
        const merged = new Uint8Array(length);
        length = 0;
        for (const next of parts) {
            merged.set(next, length);
            length += next.byteLength;
        }
        return merged;
    }

    public net(): Net | null {
        return this.transport.net ?? null;
    }

    public getRunningProgram(): Promise<string> {
        if (this.getRunningProgramPromise !== null) {
            return this.getRunningProgramPromise;
        }
        this.getRunningProgramPromise = new Promise<string>((resolve) => {
            this.getRunningProgramResolve = resolve;
        });
        this.sendClientMessage("wc-get-running-program");
        return this.getRunningProgramPromise;
    }
}

function encodeSockdriveChanges(changes: {
    url: string,
    persist: Uint8Array,
}[]) {
    function writeUint32(container: Uint8Array, value: number, offset: number) {
        container[offset] = value & 0xFF;
        container[offset + 1] = (value & 0x0000FF00) >> 8;
        container[offset + 2] = (value & 0x00FF0000) >> 16;
        container[offset + 3] = (value & 0xFF000000) >> 24;
        return offset + 4;
    }

    const encoder = new TextEncoder();

    const urls = [];
    let totalSize = 0;
    for (const { url, persist } of changes) {
        urls.push(encoder.encode(url));
        totalSize += persist.length + urls[urls.length - 1].length + 8;
    }

    const result = new Uint8Array(totalSize);
    let offset = 0;
    for (let i = 0; i < changes.length; i++) {
        const url = urls[i];
        const persist = changes[i].persist;

        offset = writeUint32(result, url.length, offset);
        result.set(url, offset);
        offset += url.length;

        offset = writeUint32(result, persist.length, offset);
        result.set(persist, offset);
        offset += persist.length;
    }

    return result;
}
