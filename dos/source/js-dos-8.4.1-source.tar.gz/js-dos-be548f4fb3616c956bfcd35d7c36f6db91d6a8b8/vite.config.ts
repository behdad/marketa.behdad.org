import { defineConfig } from "vite";
import preact from "@preact/preset-vite";
import basicSsl from "@vitejs/plugin-basic-ssl";

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [preact(), basicSsl()],
    server: {
        port: 443,
        host: "0.0.0.0",
        cors: true,
        allowedHosts: ["test.js-dos.com"],
    },
    build: {
        rollupOptions: {
            output: {
                entryFileNames: "js-dos.js",
                assetFileNames: (info) => {
                    return info.name === "index.css" ? "js-dos.css" : info.name;
                },
            },
        },
    },
    define: {
        JSDOS_VERSION: JSON.stringify(process.env.npm_package_version),
    },
});
